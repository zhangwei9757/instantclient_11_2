<?xml ?>

<helpset>

<title>Oracle Net Manager</title>

<maps>
   <mapref location="mgr.map"/>
</maps>

<links>
</links>

<view>
   <type>oracle.help.navigator.tocNavigator.TOCNavigator</type>
   <data engine="oracle.help.engine.HHCEngine">mgr.hhc</data>
</view>

<view>
   <name>OHJ_WIZARD_GENERATED_SEARCH</name>
   <title>Oracle Net Manager</title>
   <type>oracle.help.navigator.searchNavigator.SearchNavigator</type>
   <data engine="oracle.help.engine.SearchEngine">mgr.idx</data>
</view>


</helpset>

<!OHJ_WIZARD_PROPERTY MAP_OPTION ="CREATE_META" >
<!OHJ_WIZARD_PROPERTY SEARCH_NUMBER ="TRUE" >
<!OHJ_WIZARD_PROPERTY SOURCE_TOOL ="RoboHTML 2000 -- HTMLHelp" >
<!OHJ_WIZARD_PROPERTY SEARCH_ENCODING ="8859_1" >
<!OHJ_WIZARD_PROPERTY BACKUP_FILES ="TRUE" >
<!OHJ_WIZARD_PROPERTY POPUP_OPTION ="CONVERT" >
<!OHJ_WIZARD_PROPERTY GENERATE_SEARCH ="TRUE" >
<!OHJ_WIZARD_PROPERTY INCLUDE_SUBDIR ="TRUE" >
<!OHJ_WIZARD_PROPERTY ALINK_OPTION ="CONVERT" >
<!OHJ_WIZARD_PROPERTY TARGET_BROWSER ="ICE Browser 5.0 (default)" >
<!OHJ_WIZARD_PROPERTY SEARCH_CASE ="TRUE" >
<!OHJ_WIZARD_PROPERTY FILE_BASENAME ="mgr" >
